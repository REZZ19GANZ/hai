pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
pkg install tesseract -y
npm install
